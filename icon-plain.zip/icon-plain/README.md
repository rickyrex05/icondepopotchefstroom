# ICON PLAIN

A Pen created on CodePen.

Original URL: [https://codepen.io/Rihana-Cilliers/pen/PwbGXKz](https://codepen.io/Rihana-Cilliers/pen/PwbGXKz).

